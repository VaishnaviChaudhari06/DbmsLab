# DBMS Practical Codes

Separate folders contain runnable starter scripts for the practical experiments shared in the lab manual.

## Files
- `Experiment_1_ER_EER/`: ER/EER diagram planning guide (diagram is conceptual, not executable SQL).
- `Experiment_2_DDL_DCL/`: MySQL University Management System, DDL and DCL.
- `Experiment_3_DML_LIKE/`: MySQL employee table, pattern matching, Boolean and arithmetic queries.
- `Experiment_4_MongoDB/`: MongoDB university CRUD, sorting and aggregation.
- `Experiment_5_Subqueries/`: MySQL nested subqueries.
- `Experiment_6_Triggers/`: MySQL-compatible row-level trigger example and audit log. MySQL does not support statement-level triggers.
- `Experiment_7_PL_SQL/`: Oracle PL/SQL procedure/function/cursor examples. Run in Oracle SQL Developer, not MySQL.
- `Experiment_8_MongoDB_Operations/`: MongoDB product CRUD, conditionals, regex, arrays and aggregation.
- `Experiment_9_MySQL_Spatial/`: MySQL spatial POINT examples.

## Important
1. Run each script in the database tool named in that folder.
2. Several scripts create databases/tables. If rerunning, drop the old test database or remove existing sample rows first.
3. The MySQL DCL example may require an administrator account and permission to create users/grant privileges.
4. MySQL triggers are row-level (`FOR EACH ROW`); they do not support statement-level triggers. Experiment 6 includes an explicit note and a practical alternative.
5. The PL/SQL example uses Oracle syntax and is not MySQL syntax.
