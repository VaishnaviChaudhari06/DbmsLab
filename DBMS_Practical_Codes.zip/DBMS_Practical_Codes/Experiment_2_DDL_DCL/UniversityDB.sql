-- Experiment 2: DDL and DCL in MySQL
CREATE DATABASE IF NOT EXISTS UniversityDB;
USE UniversityDB;

CREATE TABLE IF NOT EXISTS Student (
    StudentID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    DOB DATE
);

CREATE TABLE IF NOT EXISTS Instructor (
    InstructorID INT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Department VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS Course (
    CourseID INT PRIMARY KEY,
    CourseName VARCHAR(100) NOT NULL,
    InstructorID INT,
    FOREIGN KEY (InstructorID) REFERENCES Instructor(InstructorID)
);

CREATE TABLE IF NOT EXISTS Enrollment (
    StudentID INT,
    CourseID INT,
    EnrollmentDate DATE,
    PRIMARY KEY (StudentID, CourseID),
    FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
    FOREIGN KEY (CourseID) REFERENCES Course(CourseID)
);

-- Sample data
INSERT INTO Instructor VALUES
(1, 'Dr. Mehta', 'mehta@example.com', 'IT')
ON DUPLICATE KEY UPDATE Name=VALUES(Name);

INSERT INTO Student VALUES
(1, 'Asha', 'Patil', 'asha@example.com', '2005-02-14')
ON DUPLICATE KEY UPDATE FirstName=VALUES(FirstName);

INSERT INTO Course VALUES (101, 'Database Systems', 1)
ON DUPLICATE KEY UPDATE CourseName=VALUES(CourseName);

INSERT INTO Enrollment VALUES (1, 101, CURRENT_DATE)
ON DUPLICATE KEY UPDATE EnrollmentDate=VALUES(EnrollmentDate);

-- DDL example: ALTER
ALTER TABLE Course ADD COLUMN IF NOT EXISTS Credits INT DEFAULT 3;

-- DCL: run with an account allowed to create users and grant privileges.
CREATE USER IF NOT EXISTS 'student_user'@'localhost' IDENTIFIED BY 'ChangeMe_123!';
GRANT SELECT, INSERT, UPDATE ON UniversityDB.* TO 'student_user'@'localhost';
REVOKE UPDATE ON UniversityDB.* FROM 'student_user'@'localhost';

SELECT * FROM Student;
SELECT * FROM Instructor;
SELECT * FROM Course;
SELECT * FROM Enrollment;
