-- Experiment 9: Spatial column creation and querying (MySQL 8+)
CREATE DATABASE IF NOT EXISTS SpatialDB;
USE SpatialDB;

CREATE TABLE IF NOT EXISTS Locations (
    id INT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    location POINT NOT NULL SRID 4326
);

-- MySQL POINT coordinates are X=longitude, Y=latitude.
INSERT INTO Locations (id, name, location) VALUES
(1, 'Pune', ST_GeomFromText('POINT(73.8567 18.5204)', 4326)),
(2, 'Mumbai', ST_GeomFromText('POINT(72.8777 19.0760)', 4326))
ON DUPLICATE KEY UPDATE
name=VALUES(name), location=VALUES(location);

-- Retrieve geometry as readable text
SELECT name, ST_AsText(location) AS coordinates FROM Locations;

-- Retrieve longitude and latitude separately
SELECT name,
       ST_X(location) AS longitude,
       ST_Y(location) AS latitude
FROM Locations;

-- Optional spatial index (supported by MySQL spatial columns)
ALTER TABLE Locations ADD SPATIAL INDEX idx_location (location);
