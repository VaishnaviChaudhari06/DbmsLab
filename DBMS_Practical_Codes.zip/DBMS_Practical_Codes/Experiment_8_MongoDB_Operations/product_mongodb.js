// Experiment 8: MongoDB product CRUD, queries, arrays, regex and aggregation
use ProductDB;

// Clear only this lab collection so reruns don't create duplicate sample rows.
db.products.drop();

db.products.insertMany([
  {name: "Laptop", price: 50000, category: "Electronics", tags: ["computer", "office"]},
  {name: "Apple", price: 30, category: "Food", tags: ["fruit", "healthy"]},
  {name: "Mobile", price: 20000, category: "Electronics", tags: ["phone", "communication"]},
  {name: "Adapter", price: 150, category: "Electronics", tags: ["charger", "accessory"]},
  {name: "Banana", price: 10, category: "Food", tags: ["fruit", "healthy"]}
]);

// Read operations
db.products.find();
db.products.findOne({name: "Laptop"});

// Conditional queries
db.products.find({price: {$gt: 100}});
db.products.find({price: {$lt: 50}});
db.products.find({$or: [{category: "Electronics"}, {price: {$lt: 50}}]});
db.products.find({category: {$in: ["Food", "Electronics"]}});
db.products.find({price: {$not: {$gt: 100}}});

// Array and regular expression
db.products.find({tags: "fruit"});
db.products.find({name: {$regex: "^A", $options: "i"}});

// Update and delete
db.products.updateOne({name: "Laptop"}, {$set: {price: 55000}});
db.products.deleteOne({name: "Adapter"});

// Aggregation: total price by category
db.products.aggregate([
  {$group: {_id: "$category", total: {$sum: "$price"}}}
]);

db.products.find();
