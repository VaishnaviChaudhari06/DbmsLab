-- Experiment 6: Triggers in a banking database (MySQL)
-- Note: MySQL supports FOR EACH ROW triggers, not statement-level triggers.
CREATE DATABASE IF NOT EXISTS BankingDB;
USE BankingDB;

CREATE TABLE IF NOT EXISTS Transactions (
    TransactionID INT PRIMARY KEY,
    AccountNo VARCHAR(20) NOT NULL,
    Amount DECIMAL(12,2) NOT NULL,
    Type ENUM('Deposit', 'Withdrawal') NOT NULL,
    TransactionDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS AuditLog (
    AuditID INT AUTO_INCREMENT PRIMARY KEY,
    Event VARCHAR(100) NOT NULL,
    EventDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Details VARCHAR(255)
);

DROP TRIGGER IF EXISTS LogHighWithdrawal;
DELIMITER //
CREATE TRIGGER LogHighWithdrawal
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    IF NEW.Type = 'Withdrawal' AND NEW.Amount > 10000 THEN
        INSERT INTO AuditLog(Event, Details)
        VALUES ('High Withdrawal', CONCAT('Account=', NEW.AccountNo, ', Amount=', NEW.Amount));
    END IF;
END//
DELIMITER ;

-- Sample rows: each inserted row fires the row-level trigger
INSERT INTO Transactions VALUES
(1, 'ACC1001', 15000, 'Withdrawal', CURRENT_TIMESTAMP),
(2, 'ACC1002', 5000, 'Withdrawal', CURRENT_TIMESTAMP),
(3, 'ACC1003', 20000, 'Deposit', CURRENT_TIMESTAMP)
ON DUPLICATE KEY UPDATE Amount=VALUES(Amount);

SELECT * FROM Transactions;
SELECT * FROM AuditLog;

-- Statement-level trigger alternative:
-- MySQL has no statement-level triggers. To record a batch operation, explicitly
-- insert one audit row from the script/application after the batch insert:
INSERT INTO AuditLog(Event, Details)
VALUES ('Batch Insert (manual audit)', 'Batch insert script executed');
