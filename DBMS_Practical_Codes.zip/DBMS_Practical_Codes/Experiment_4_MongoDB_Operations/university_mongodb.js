// Experiment 4: MongoDB University CRUD, sorting, aggregation
use universityDB;

db.students.insertMany([
  {roll_no: 1, name: "John", course: "CS", marks: 85},
  {roll_no: 2, name: "Alice", course: "IT", marks: 90},
  {roll_no: 3, name: "Bob", course: "CS", marks: 75}
], { ordered: false });

db.createCollection("courses");
db.courses.insertMany([
  {course_id: "CS", course_name: "Computer Science"},
  {course_id: "IT", course_name: "Information Technology"}
], { ordered: false });

// Read all and filter
db.students.find();
db.students.find({course: "CS"});

// Update Bob's marks
db.students.updateOne({roll_no: 3}, {$set: {marks: 80}});

// Sort marks descending
db.students.find().sort({marks: -1});

// Average marks by course
db.students.aggregate([
  {$group: {_id: "$course", avgMarks: {$avg: "$marks"}}}
]);

// Delete John (run this after viewing the initial records)
db.students.deleteOne({roll_no: 1});

// Final view
db.students.find();
