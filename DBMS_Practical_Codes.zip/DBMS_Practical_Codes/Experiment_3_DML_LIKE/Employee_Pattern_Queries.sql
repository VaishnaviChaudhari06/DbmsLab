-- Experiment 3: LIKE, wildcards, Boolean and arithmetic operators (MySQL)
CREATE DATABASE IF NOT EXISTS CompanyDB;
USE CompanyDB;

CREATE TABLE IF NOT EXISTS Employee (
    EmpID INT PRIMARY KEY,
    Name VARCHAR(50),
    Department VARCHAR(30),
    Salary DECIMAL(10,2),
    City VARCHAR(30)
);

INSERT INTO Employee VALUES
(1, 'Amit Sharma', 'IT', 50000, 'Pune'),
(2, 'Anita Verma', 'HR', 40000, 'Mumbai'),
(3, 'Ravi Kumar', 'Finance', 55000, 'Delhi'),
(4, 'Neha Singh', 'IT', 60000, 'Pune'),
(5, 'Sunil Patil', 'Marketing', 45000, 'Nagpur'),
(6, 'Priya Mehta', 'Finance', 47000, 'Delhi'),
(7, 'Anil Deshmukh', 'IT', 65000, 'Mumbai'),
(8, 'Asha Reddy', 'HR', 42000, 'Hyderabad'),
(9, 'Rakesh Gupta', 'Marketing', 38000, 'Pune'),
(10, 'Kiran Joshi', 'Finance', 52000, 'Mumbai')
ON DUPLICATE KEY UPDATE Name=VALUES(Name);

-- 1. Name starts with A
SELECT * FROM Employee WHERE Name LIKE 'A%';
-- 2. Name ends with a
SELECT * FROM Employee WHERE Name LIKE '%a';
-- 3. Name contains sh
SELECT * FROM Employee WHERE Name LIKE '%sh%';
-- 4. Second character is n
SELECT * FROM Employee WHERE Name LIKE '_n%';
-- 5. City starts with P and department is IT
SELECT * FROM Employee WHERE City LIKE 'P%' AND Department = 'IT';
-- 6. City is Mumbai or salary is above 50000
SELECT * FROM Employee WHERE City = 'Mumbai' OR Salary > 50000;
-- 7. Name does not contain a
SELECT * FROM Employee WHERE Name NOT LIKE '%a%';
-- 8. Show IT salary after a 10% increase (does not modify stored data)
SELECT EmpID, Name, Salary, Salary + (Salary * 0.10) AS SalaryAfterIncrease
FROM Employee WHERE Department = 'IT';
-- 9. Salary between 45000 and 60000
SELECT * FROM Employee WHERE Salary BETWEEN 45000 AND 60000;
-- 10. Employees from Pune whose names start with R
SELECT * FROM Employee WHERE City = 'Pune' AND Name LIKE 'R%';
-- 11. Arithmetic: annual salary
SELECT Name, Salary, Salary * 12 AS AnnualSalary FROM Employee;
-- 12. Example update (uncomment only if you want to change stored salaries)
-- UPDATE Employee SET Salary = Salary * 1.10 WHERE Department = 'IT';
