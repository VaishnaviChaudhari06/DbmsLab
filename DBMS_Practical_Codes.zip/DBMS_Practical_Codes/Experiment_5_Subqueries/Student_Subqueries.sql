-- Experiment 5: Nested subqueries in MySQL
CREATE DATABASE IF NOT EXISTS StudentSubqueryDB;
USE StudentSubqueryDB;

CREATE TABLE IF NOT EXISTS Departments (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS Students (
    StudentID INT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    DeptID INT,
    Marks DECIMAL(5,2),
    FOREIGN KEY (DeptID) REFERENCES Departments(DeptID)
);

INSERT INTO Departments VALUES
(1, 'IT'), (2, 'Computer'), (3, 'Mechanical')
ON DUPLICATE KEY UPDATE DeptName=VALUES(DeptName);

INSERT INTO Students VALUES
(1, 'Asha', 1, 88), (2, 'Rohan', 1, 76),
(3, 'Meera', 2, 92), (4, 'Kabir', 2, 81),
(5, 'Neha', 3, 67), (6, 'Arjun', 3, 73)
ON DUPLICATE KEY UPDATE Name=VALUES(Name);

-- 1. Students in IT department (IN)
SELECT Name FROM Students
WHERE DeptID IN (SELECT DeptID FROM Departments WHERE DeptName = 'IT');

-- 2. Students not in IT department (NOT IN)
SELECT Name FROM Students
WHERE DeptID NOT IN (SELECT DeptID FROM Departments WHERE DeptName = 'IT');

-- 3. Students scoring above every student in DeptID 3 (> ALL)
SELECT Name, Marks FROM Students
WHERE Marks > ALL (SELECT Marks FROM Students WHERE DeptID = 3);

-- 4. Students scoring above at least one student in DeptID 3 (> ANY)
SELECT Name, Marks FROM Students
WHERE Marks > ANY (SELECT Marks FROM Students WHERE DeptID = 3);

-- 5. Department IDs with more than one student (set cardinality)
SELECT DeptID FROM Students
GROUP BY DeptID
HAVING COUNT(*) > 1;

-- 6. EXISTS example
SELECT d.DeptName FROM Departments d
WHERE EXISTS (SELECT 1 FROM Students s WHERE s.DeptID = d.DeptID);

-- 7. Correlated subquery: students scoring above their department average
SELECT s.Name, s.Marks
FROM Students s
WHERE s.Marks > (
  SELECT AVG(s2.Marks) FROM Students s2 WHERE s2.DeptID = s.DeptID
);
