-- Experiment 7: Oracle PL/SQL stored procedure, cursor and function
-- Run in Oracle SQL Developer, not MySQL Workbench.
-- Create table and sample data first:
CREATE TABLE Employee (
    EmpID NUMBER PRIMARY KEY,
    Name VARCHAR2(50),
    Department VARCHAR2(30),
    Salary NUMBER(10,2),
    Bonus NUMBER(10,2)
);

INSERT INTO Employee VALUES (1, 'Amit', 'IT', 50000, 0);
INSERT INTO Employee VALUES (2, 'Neha', 'HR', 40000, 0);
INSERT INTO Employee VALUES (3, 'Ravi', 'IT', 60000, 0);
COMMIT;

-- Procedure using an explicit cursor to calculate a 10% bonus
CREATE OR REPLACE PROCEDURE CalculateBonus AS
    CURSOR emp_cursor IS SELECT EmpID, Salary FROM Employee;
BEGIN
    FOR emp_rec IN emp_cursor LOOP
        UPDATE Employee
        SET Bonus = emp_rec.Salary * 0.10
        WHERE EmpID = emp_rec.EmpID;
    END LOOP;
    COMMIT;
END;
/

-- Function returning employee count for a department
CREATE OR REPLACE FUNCTION GetDeptCount(dept_name IN VARCHAR2)
RETURN NUMBER
AS
    dept_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO dept_count
    FROM Employee
    WHERE Department = dept_name;
    RETURN dept_count;
END;
/

-- Execute and verify
BEGIN
    CalculateBonus;
END;
/

SELECT * FROM Employee;
SELECT GetDeptCount('IT') AS IT_Employee_Count FROM dual;
