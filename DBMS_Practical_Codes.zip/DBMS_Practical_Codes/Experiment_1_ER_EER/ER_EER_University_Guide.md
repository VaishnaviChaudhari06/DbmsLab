# Experiment 1 — ER/EER Diagram (University Management System)

This experiment is a diagram, not a SQL program. Draw the entities and relationships below in draw.io, diagrams.net, or on paper.

## Entities and attributes
- **STUDENT** (strong entity): `StudentID` (PK), `Name` (composite: FirstName, LastName), `DOB`, `Age` (derived from DOB), `{PhoneNumber}` (multivalued).
- **DEPARTMENT** (strong entity): `DepartmentID` (PK), `DepartmentName`.
- **COURSE** (strong entity): `CourseID` (PK), `CourseName`, `Credits`.
- **INSTRUCTOR** (strong entity / superclass): `InstructorID` (PK), `Name`, `Email`.
- **PROFESSOR** (subclass of INSTRUCTOR): `ResearchArea`.
- **TEACHING_ASSISTANT** (subclass of INSTRUCTOR): `HourlyRate`.
- **ENROLLMENT** (associative entity): `StudentID` (PK/FK), `CourseID` (PK/FK), `EnrollmentDate`, `Grade`.
- **DEPENDENT** (weak entity owned by STUDENT): partial key `DependentName`, `Relationship`, `DOB`. Its identifying key is `(StudentID, DependentName)`.

## Relationships and constraints
- DEPARTMENT 1 — N STUDENT (each student belongs to one department; a department may have many students).
- DEPARTMENT 1 — N COURSE.
- INSTRUCTOR 1 — N COURSE (each course has one instructor in this simplified design).
- STUDENT M — N COURSE, resolved through ENROLLMENT.
- STUDENT 1 — N DEPENDENT (identifying relationship; DEPENDENT cannot exist without STUDENT).

## Enhanced concepts
- **Specialization:** INSTRUCTOR is specialized into PROFESSOR and TEACHING_ASSISTANT. Mark whether the split is disjoint/overlapping and total/partial according to the assumptions given by your instructor.
- **Generalization:** The reverse idea: combine common attributes of PROFESSOR and TEACHING_ASSISTANT into INSTRUCTOR.
- **Aggregation:** Draw STUDENT — ENROLLMENT — COURSE, then put a box around the ENROLLMENT relationship and its participating entities/relationship to show that a course enrollment can be treated as a higher-level unit (for example, an instructor evaluates a particular enrollment).

## Diagram notation
- Primary key: underline attribute.
- Composite attribute: Name branches into FirstName and LastName.
- Derived attribute: dashed oval `Age`.
- Multivalued attribute: double oval `{PhoneNumber}`.
- Weak entity: double rectangle; identifying relationship: double diamond; partial key: dashed underline.
- Specialization: triangle/ISA connector between superclass and subclasses.
- Show 1, N, M cardinalities and total participation with double lines where applicable.

This is a modeling guide; draw the actual ER/EER diagram separately for submission.
